##通过php_printer扩展，使用php连接控制打印机

##php_printer.dll使用
- 仅限windows系统下使用
- 目前最高版本5.5
- 扩展版本与php版本必须完全相同

[php_printer.dll下载地址](http://windows.php.net/downloads/pecl/snaps/printer/0.1.0-dev/)